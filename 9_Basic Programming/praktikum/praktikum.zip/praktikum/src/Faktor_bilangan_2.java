public class Faktor_bilangan_2 {
	public static void main(String args[]) {
		int n = 9;
		int nilai = 0 + n;
		for (int nilai = n;n > 0; n--  ) {
			System.out.println(nilai);	
			}
		}
	}
