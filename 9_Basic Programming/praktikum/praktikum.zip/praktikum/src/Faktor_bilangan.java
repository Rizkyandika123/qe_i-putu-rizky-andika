public class Faktor_bilangan {
	public static void main(String args[]) {
		int input = 9;
		int tambah = 0;
		System.out.println("Faktor dari angka " + input);
		for (int d = 1; d <= input; d++) {
			tambah++;
			if (input % tambah == 0) {
				System.out.println(tambah);
			}
		}
	}
}

