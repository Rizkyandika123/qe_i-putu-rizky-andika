
public class segitiga {
	public static void main (String args []){
		int alas = 20;
		int tinggi = 25;
		int segitiga = alas*tinggi/2;
		System.out.print(segitiga);
	}

}
