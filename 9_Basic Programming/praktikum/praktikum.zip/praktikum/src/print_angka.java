public class print_angka {
	public static void main(String args[]) {
		int input = 5;
		for (int d = 1; d <= input; d++) {
			System.out.println(d);
		}
			
	}
}
