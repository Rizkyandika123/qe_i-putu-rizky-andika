
public class Konversi_nilai {
	public static void main (String args []){
		int studentScore = 70;
		
		if (studentScore>=80 && studentScore<=100) {
			  System.out.println("A");
		} else if (studentScore>=65 && studentScore<=79 ){
			System.out.print("B+");
		} else if (studentScore>=50 && studentScore<=64 ){
			System.out.print("B");
		} else if (studentScore>=35 && studentScore<=49 ){
			System.out.print("C");
		} else if (studentScore>=0 && studentScore<=34 ){
			System.out.print("D");
		} else if (studentScore<0 ){
			System.out.print("Invalid");
		}
	}

}

